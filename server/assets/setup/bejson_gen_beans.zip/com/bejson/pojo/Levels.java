/**
  * Copyright 2024 bejson.com 
  */
package com.bejson.pojo;
import java.util.List;

/**
 * Auto-generated: 2024-06-24 17:28:6
 *
 * @author bejson.com (i@bejson.com)
 * @website http://www.bejson.com/java2pojo/
 */
public class Levels {

    private String title;
    private String author;
    private String rewardsName;
    private String desc;
    private List<String> imgList;
    private List<Remarks> remarks;
    public void setTitle(String title) {
         this.title = title;
     }
     public String getTitle() {
         return title;
     }

    public void setAuthor(String author) {
         this.author = author;
     }
     public String getAuthor() {
         return author;
     }

    public void setRewardsName(String rewardsName) {
         this.rewardsName = rewardsName;
     }
     public String getRewardsName() {
         return rewardsName;
     }

    public void setDesc(String desc) {
         this.desc = desc;
     }
     public String getDesc() {
         return desc;
     }

    public void setImgList(List<String> imgList) {
         this.imgList = imgList;
     }
     public List<String> getImgList() {
         return imgList;
     }

    public void setRemarks(List<Remarks> remarks) {
         this.remarks = remarks;
     }
     public List<Remarks> getRemarks() {
         return remarks;
     }

}