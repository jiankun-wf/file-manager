/**
  * Copyright 2024 bejson.com 
  */
package com.bejson.pojo;

/**
 * Auto-generated: 2024-06-24 17:28:6
 *
 * @author bejson.com (i@bejson.com)
 * @website http://www.bejson.com/java2pojo/
 */
public class Remarks {

    private String value;
    public void setValue(String value) {
         this.value = value;
     }
     public String getValue() {
         return value;
     }

}