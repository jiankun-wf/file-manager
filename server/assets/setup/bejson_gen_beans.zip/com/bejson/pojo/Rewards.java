/**
  * Copyright 2024 bejson.com 
  */
package com.bejson.pojo;
import java.util.List;

/**
 * Auto-generated: 2024-06-24 17:28:6
 *
 * @author bejson.com (i@bejson.com)
 * @website http://www.bejson.com/java2pojo/
 */
public class Rewards {

    private String href;
    private String title;
    private List<Levels> levels;
    private String type;
    private String awardName;
    public void setHref(String href) {
         this.href = href;
     }
     public String getHref() {
         return href;
     }

    public void setTitle(String title) {
         this.title = title;
     }
     public String getTitle() {
         return title;
     }

    public void setLevels(List<Levels> levels) {
         this.levels = levels;
     }
     public List<Levels> getLevels() {
         return levels;
     }

    public void setType(String type) {
         this.type = type;
     }
     public String getType() {
         return type;
     }

    public void setAwardName(String awardName) {
         this.awardName = awardName;
     }
     public String getAwardName() {
         return awardName;
     }

}