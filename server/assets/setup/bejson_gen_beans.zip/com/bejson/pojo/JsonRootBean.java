/**
  * Copyright 2024 bejson.com 
  */
package com.bejson.pojo;
import java.util.List;

/**
 * Auto-generated: 2024-06-24 17:28:6
 *
 * @author bejson.com (i@bejson.com)
 * @website http://www.bejson.com/java2pojo/
 */
public class JsonRootBean {

    private String href;
    private String title;
    private List<Rewards> rewards;
    public void setHref(String href) {
         this.href = href;
     }
     public String getHref() {
         return href;
     }

    public void setTitle(String title) {
         this.title = title;
     }
     public String getTitle() {
         return title;
     }

    public void setRewards(List<Rewards> rewards) {
         this.rewards = rewards;
     }
     public List<Rewards> getRewards() {
         return rewards;
     }

}