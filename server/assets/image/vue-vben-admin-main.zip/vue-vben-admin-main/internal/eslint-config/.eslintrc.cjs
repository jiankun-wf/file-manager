module.exports = {
  root: true,
  extends: ['@vben/eslint-config/strict'],
};
