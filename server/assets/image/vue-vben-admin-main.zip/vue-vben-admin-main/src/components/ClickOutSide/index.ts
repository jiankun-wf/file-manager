import { withInstall } from '@/utils';
import clickOutSide from './src/ClickOutSide.vue';

export const ClickOutSide = withInstall(clickOutSide);
