import { withInstall } from '@/utils';
import ellipsisText from './src/EllipsisText.vue';

export const EllipsisText = withInstall(ellipsisText);
